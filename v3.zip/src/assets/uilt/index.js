const isB = val => val && typeof val === 'boolean'

export default { isB }